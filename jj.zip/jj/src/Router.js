import React, { Component } from 'react';
import { Route, Switch} from "react-router-dom";
import AppBar from './AppBar';
import Sidemenu from './cmp/Sidemenu';
import About from './cmp/About';
import Services from './cmp/Services'
import Contact from './cmp/Contact'
import Home from './cmp/Home';
import Carousel from './Carousel';
import Demo from './Demo';

class Router_Set extends Component {
    render() {
        return (
            <div>
                  
    <Switch>
       
       <Route exact path="/" component={Carousel}/> 
       <Route path="/contact" component={Contact}/>
       <Route path="/about" component={About}/>
       <Route path="/services" component={Services}/>
       <Route path="/demo" component={Demo}></Route>
    
    </Switch>




            </div>
        );
    }
}

export default Router_Set;