import { Button, Container, TextField} from '@material-ui/core';
import React, { Component } from 'react';
import {Zoom,Bounce ,Fade} from 'react-reveal/';
import {Grid, Hidden} from '@material-ui/core';
import Recaptcha from 'react-recaptcha';
import './Services.css';
class Contact extends Component {
    render() {
        return (
            <div>
                  
              

       
    <br/><br/><br/>   
    <center>
                    <Zoom left cascade>
               <div className="ser">CONTACT US</div>
               </Zoom>
<Bounce top>

 <form  style={{
         backgroundImage: `url("./images/contact2.jpg")`,
         color:'white',
         backgroundSize: "cover",
          height: "74vh",

      }}  > 
 <Zoom left cascade>
  <p style={{fontSize:'20px',color:'pink'}}>Contact_Form</p>
 </Zoom>
     
    <div>
     <Fade left>
     <TextField type='text' name='name' id='name' label='Enter Name'  variant="filled"/><br/>
     <TextField type='email' name='email' id='email' label='Enter Email'  variant="filled"/><br/><br/>
     </Fade>

     <Fade right>
     <TextField type='number' name='number' id='number' label='Enter Contact'  variant="filled"/><br/>
     <TextField type='text' name='msg' id="msg" label="Enter Message" multiline rowsMax={4} variant="filled"/><br/><br/>
     </Fade>

     <Container>
             <Recaptcha  sitekey="6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI" />
            </Container><br/>
 
     <Fade left>
     <TextField  variant="outlined"  type='submit'/>
     </Fade>


    
     </div>
     
     
 </form>





</Bounce>     



    </center>

 

               
            </div>
        );
    }
}

export default Contact;