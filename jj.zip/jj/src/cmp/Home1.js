import React, { Component } from 'react';
import Home from './Home';
class Home1 extends Component {
    render() {
        return (
            <div>
                <Home/>
                    home1
            </div>
        );
    }
}

export default Home1;     