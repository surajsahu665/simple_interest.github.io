import React from 'react';
import IconButton from '@material-ui/core/IconButton';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import { Button,Grid,Hidden} from '@material-ui/core';
import { red } from '@material-ui/core/colors';
import './Menus.css';
const ITEM_HEIGHT = 48;

export default function LongMenu() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <IconButton
        aria-label="more"
        aria-controls="long-menu"
        aria-haspopup="true"
        onClick={handleClick}

      >
        <span style={{marginTop:"-20px"}} >||||</span>
      </IconButton>
      <Menu
        id="long-menu"
        anchorEl={anchorEl}
        keepMounted
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 41.5,
            width: '200ch',
            color:red,
          },
        }}
      >

{/* 
<MenuItem>
            <a href="/home1"><Button><span className="sk">Home1</span></Button></a>
          </MenuItem> */}
       <MenuItem  onClick={handleClose}>
            <a href="/"><Button><span className="sk">Home</span></Button></a>
          </MenuItem>

          <MenuItem  onClick={handleClose}>
            <a href="#services"><Button><span className="sk">Services</span></Button></a>
          </MenuItem>

          <MenuItem  onClick={handleClose}>
            <a href="/#contact"><Button><span className="sk">Contact</span></Button></a>
          </MenuItem>
          
          <MenuItem  onClick={handleClose}>
            <a href="/#about"><Button><span className="sk">About</span></Button></a>
          </MenuItem>
          
          
          
          
    
      </Menu>
    </div>
  );
}
