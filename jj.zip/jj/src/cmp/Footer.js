import React, { Component } from 'react';
import BackToTop from './Home';
import './Services.css';
import {Button, Container,Grid, TextField}  from '@material-ui/core';
import { Route,NavLink} from "react-router-dom";

class Footer extends Component {
    render() {
        return (
            <div>
                <center>
                   <div className="ser"> </div> <br/>


<div style={{backgroundColor:"whitesmoke"}}>
      
<Grid item xs={12} container spacing={2}>



<Grid item lg={4} sm={6} xs={12}>
       
       <center>

       Partners: Kayya Creations | Kayya Media Ventures
        © 2020 Copyright Krimtel Gensease Technologies Pvt. Ltd. All rights reserverd.
      
       </center>
      </Grid>


        <Grid item lg={4} sm={6} xs={12}>
        
    
              
        <span><a href="/"><Button variant="outlined" color="primary">  HOME</Button> </a></span>
        <span><a href="./#services"><Button variant="outlined" color="primary"> SERVICES</Button></a></span>
        <span><a href="./#contact"><Button variant="outlined" color="primary"> CONTACT</Button> </a></span>
        <span><a href='/#about'><Button variant="outlined" color="primary"> ABOUT</Button></a></span>
                    
                  
                      
        
        
        </Grid>

        <Grid item lg={2} sm={6} xs={12}>
        <TextField
        label="Enter Email For Subscribe"/>
        </Grid>

        <Grid item lg={2} sm={6} xs={12}>
        <Button type="submit" variant="outlined" color="secondary">submit</Button>
        </Grid>

    
       
     
</Grid>

</div>
    
                </center>
            </div>
        );
    }
}

export default Footer;