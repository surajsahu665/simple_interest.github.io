import React from 'react';
import PropTypes from 'prop-types';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import useScrollTrigger from '@material-ui/core/useScrollTrigger';
import Box from '@material-ui/core/Box';
import Container from '@material-ui/core/Container';
import Fab from '@material-ui/core/Fab';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import Zoom from '@material-ui/core/Zoom';
import Sidemenu from './Sidemenu';
import {Button, ButtonGroup ,Checkbox ,Radio,Slider,Select,MenuItem,TextField,Switch ,Grid, Hidden} from '@material-ui/core';
import { Route,NavLink} from "react-router-dom";
import './Home.css';

const useStyles = makeStyles((theme) => ({
  root: {
    position: 'fixed',
    bottom: theme.spacing(2),
    right: theme.spacing(2),
  },
}));

function ScrollTop(props) {
  const { children, window } = props;
  const classes = useStyles();
  // Note that you normally won't need to set the window ref as useScrollTrigger
  // will default to window.
  // This is only being set here because the demo is in an iframe.
  const trigger = useScrollTrigger({
    target: window ? window() : undefined,
    disableHysteresis: true,
    threshold: 100,
  });

  const handleClick = (event) => {
    const anchor = (event.target.ownerDocument || document).querySelector('#back-to-top-anchor');

    if (anchor) {
      anchor.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  return (
    <Zoom in={trigger}>
      <div onClick={handleClick} role="presentation" className={classes.root}>
        {children}
      </div>
    </Zoom>
  );
}

ScrollTop.propTypes = {
  children: PropTypes.element.isRequired,
  /**
   * Injected by the documentation to work in an iframe.
   * You won't need it on your project.
   */
  window: PropTypes.func,
};

export default function BackToTop(props) {
  return (
    <React.Fragment>
      <CssBaseline />
      <AppBar style={{backgroundColor:"#14364d"}}>
        <Toolbar>


        <Hidden item only={['lg','md','xl']} sm={6}><Sidemenu/>
        <img style={{height:'50px'}} src="images/krimtel.jpg" /></Hidden>

        <Hidden item only={['xs','sm']} lg={3} sm={6} xs={12}> 
        <NavLink to='/'><img style={{height:'50px'}} src="images/krimtel.jpg" /></NavLink>
        </Hidden>

        <Grid item xs={12} container spacing={-6}  style={{marginLeft:'43%'}}>
      
        
        <Hidden item only={['xs','sm']} lg={3} sm={6} xs={12}>   
        
                     <div className="menufront">  

                     
                    <Button variant="outlined" color="primary"> <span><NavLink to='/'> HOME </NavLink></span></Button>
                    <Button variant="outlined" color="primary"> <span><NavLink to='/services'> SERVICES </NavLink></span></Button>
                    <Button variant="outlined" color="primary"> <span><NavLink to='/contact'> CONTACT_US </NavLink></span></Button>
                    <Button variant="outlined" color="primary"> <span><NavLink to='/about'> ABOUT_US </NavLink></span></Button>
                    
                  
                      
                     
                      </div>
                      
                  </Hidden>


        </Grid>
        

        </Toolbar>
      </AppBar>
     
      <Container>
        <Box >
            
        </Box>
      </Container>
      <ScrollTop {...props}>
        <Fab color="secondary" size="small" aria-label="scroll back to top">
          <KeyboardArrowUpIcon />
        </Fab>
      </ScrollTop>
    </React.Fragment>
  );
}
