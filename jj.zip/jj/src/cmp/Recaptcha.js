import React, { Component } from 'react';
import Recaptcha from 'react-recaptcha';
class Recaptcha1 extends Component {
  

  
    render() {
        return (
            <div>
             <Recaptcha sitekey="6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI" />
            </div>
        );
    }
}

export default Recaptcha1;