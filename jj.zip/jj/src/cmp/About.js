import React, { Component } from 'react';
import {Zoom,Fade,Slide,Flip} from 'react-reveal';
import './Services.css'
class About extends Component {
    render() {
        return (
            <div><center>
                <br/><br/>
                <Flip>                
                <h1 className="ser">About</h1>
                </Flip>
                 <div style={{color:"pink"}}>
                 <Slide top cascade>
                <strong>Email:</strong>example@gmail.com<br/>
                <strong>Contact:</strong>+915555555555  <br/>
                </Slide>
                </div>
                </center>
                

            </div>
        );
    }
}

export default About;