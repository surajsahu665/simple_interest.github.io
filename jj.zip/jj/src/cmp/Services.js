
import React, { Component } from 'react';
import './Services.css';
import {Zoom,Fade,Slide,Flip} from 'react-reveal';
function Service() {
    
        return (
            <div>
                
                <div>
               
                <br/><br/><br/>
                <center>
                <Zoom bottom cascade>
                    
               <div className="ser">SERVICES</div>
            
               </Zoom>
               </center>
                    
            
           
            <Slide right cascade>
            <div className="card">
            <img src="images/1.jpg" alt="myPic" className="card__img"/>
            <div className="card__info">
            <center>  
            <Fade left> 
            <span className="card__category">TITLE 1</span>
            <h3 className="card__title">SERVICE 1</h3></Fade>
            </center>
            </div>
            </div>
            </Slide>
    
        
        <Fade left>
        <div className="card">
        <img src="images/1.jpg" alt="myPic" className="card__img"/>
        <div className="card__info">
        <center>
        <Fade top>
        <span className="card__category">TITLE 1</span>
        <h3 className="card__title">SERVICE 1</h3></Fade>
        </center>
        </div>
        </div></Fade>


        <Fade right>
        <div className="card">
        <img src="images/1.jpg" alt="myPic" className="card__img"/>
        <div className="card__info">
        <center>  
        <Fade right>
        <span className="card__category">TITLE 1</span>
        <h3 className="card__title">SERVICE 1</h3></Fade>
        </center>
        </div>
        </div></Fade>

    </div>
    </div>
        );
    }

export default Service;
