
import React from 'react';
import './App.css';
import Home from './cmp/Home'
import Toolbar from '@material-ui/core/Toolbar';
import Router from './Router';
import Footer from './cmp/Footer';



class App extends React.Component{
 
render() {
  
	return (
<div style={{backgroundColor:"#14364d"}}>    
<Toolbar id="back-to-top-anchor" />
    <Router/>
   <Home/>

<Footer/>




    


       </div>
      );
  }

}

export default App;