
import React from 'react';


import Contact from './components/Contact';
import {BrowserRouter as Router, Route,Link} from 'react-router-dom'

class Menu2 extends React.Component{


render() {

	return (
       <div>
       <center>
       <Router>

       <Link to="/contact">contact m</Link>

       <Route path="/contact" component={Contact}/>
       
       </Router>
        
       </center>
       </div>
      );
  }

}

export default Menu2;
